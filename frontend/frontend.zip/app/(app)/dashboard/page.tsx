import { DashboardHero } from "@/components/dashboard/dashboard-hero";
import { StatGrid } from "@/components/dashboard/stat-grid";
import { NextMatchesCard } from "@/components/dashboard/next-matches-card";
import { RecentBetsCard } from "@/components/dashboard/recent-bets-card";
import { MiniLeaderboardCard } from "@/components/dashboard/mini-leaderboard-card";
import { BadgesTeaserCard } from "@/components/dashboard/badges-teaser-card";

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-bold">Tableau de bord</h1>
        <p className="mt-1 text-muted-foreground">
          Ton activité, en un coup d&apos;œil.
        </p>
      </div>

      <DashboardHero />

      <StatGrid />

      <div className="grid gap-4 lg:grid-cols-2">
        <NextMatchesCard />
        <RecentBetsCard />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <MiniLeaderboardCard />
        </div>
        <div className="lg:col-span-2">
          <BadgesTeaserCard />
        </div>
      </div>
    </div>
  );
}
