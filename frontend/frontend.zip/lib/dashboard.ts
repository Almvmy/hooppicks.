import { PlacedBet, WalletTransaction } from "@/lib/types";

export interface StreakInfo {
  count: number;
  kind: "won" | "lost" | "none";
}

/**
 * Calcule la série en cours (victoires ou défaites consécutives) à partir
 * des paris déjà réglés (won/lost), du plus récent au plus ancien.
 */
export function computeStreak(bets: PlacedBet[]): StreakInfo {
  const settled = [...bets]
    .filter((b) => b.status === "won" || b.status === "lost")
    .sort((a, b) => new Date(b.placedAt).getTime() - new Date(a.placedAt).getTime());

  if (settled.length === 0) return { count: 0, kind: "none" };

  const kind = settled[0].status as "won" | "lost";
  let count = 0;
  for (const bet of settled) {
    if (bet.status === kind) count += 1;
    else break;
  }

  return { count, kind };
}

export interface BalancePoint {
  date: string;
  balance: number;
}

/**
 * Reconstruit la courbe d'évolution du solde à partir de l'historique des
 * transactions (qui n'est pas garanti d'être trié) et du solde actuel.
 */
export function computeBalanceSeries(
  transactions: WalletTransaction[],
  currentBalance: number
): BalancePoint[] {
  const chronological = [...transactions].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  // On repart du solde actuel et on "rembobine" en soustrayant chaque
  // mouvement pour retrouver le solde juste avant, dans l'ordre chronologique.
  const totalDelta = chronological.reduce((sum, tx) => sum + tx.amount, 0);
  let running = currentBalance - totalDelta;

  const points: BalancePoint[] = [{ date: chronological[0]?.date ?? new Date().toISOString(), balance: running }];
  for (const tx of chronological) {
    running += tx.amount;
    points.push({ date: tx.date, balance: running });
  }

  return points;
}

/**
 * Variation en points et en pourcentage entre le premier et le dernier point.
 */
export function computeSeriesDelta(points: BalancePoint[]) {
  if (points.length < 2) return { diff: 0, percent: 0 };
  const first = points[0].balance;
  const last = points[points.length - 1].balance;
  const diff = last - first;
  const percent = first === 0 ? 0 : (diff / Math.abs(first)) * 100;
  return { diff, percent };
}
