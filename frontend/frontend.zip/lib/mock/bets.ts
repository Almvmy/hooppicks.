import { PlacedBet } from "@/lib/types";

// Historique étendu pour alimenter le dashboard (série en cours, paris en attente).
// Triés du plus ancien au plus récent.
let bets: PlacedBet[] = [
  {
    id: "b0",
    selections: [
      { id: "m3-spread-home", matchId: "m3", matchLabel: "Bucks vs Heat", market: "spread", outcome: "home", label: "Bucks -2.5", odds: 1.9 },
    ],
    stake: 50,
    totalOdds: 1.9,
    potentialPayout: 95,
    status: "lost",
    placedAt: "2026-07-03T18:00:00Z",
  },
  {
    id: "b1x",
    selections: [
      { id: "m2-total-over", matchId: "m2", matchLabel: "Warriors vs Nets", market: "total", outcome: "over", label: "Plus de 220.5 pts", odds: 1.9 },
    ],
    stake: 100,
    totalOdds: 1.9,
    potentialPayout: 190,
    status: "lost",
    placedAt: "2026-07-04T19:30:00Z",
  },
  {
    id: "b2x",
    selections: [
      { id: "m5-moneyline-home", matchId: "m5", matchLabel: "Celtics vs Warriors", market: "moneyline", outcome: "home", label: "Celtics (vainqueur)", odds: 2.5 },
    ],
    stake: 100,
    totalOdds: 2.5,
    potentialPayout: 250,
    status: "won",
    placedAt: "2026-07-05T20:00:00Z",
  },
  {
    id: "b1",
    selections: [
      { id: "m6-moneyline-away", matchId: "m6", matchLabel: "Heat vs Lakers", market: "moneyline", outcome: "away", label: "Lakers (vainqueur)", odds: 1.6 },
    ],
    stake: 100,
    totalOdds: 1.6,
    potentialPayout: 160,
    status: "won",
    placedAt: "2026-07-07T15:00:00Z",
  },
  {
    id: "b2",
    selections: [
      { id: "m4-total-over", matchId: "m4", matchLabel: "Nuggets vs Suns", market: "total", outcome: "over", label: "Plus de 216.5 pts", odds: 1.9 },
    ],
    stake: 80,
    totalOdds: 1.9,
    potentialPayout: 152,
    status: "won",
    placedAt: "2026-07-08T18:00:00Z",
  },
  {
    id: "b3",
    selections: [
      { id: "m1-moneyline-home", matchId: "m1", matchLabel: "Lakers vs Celtics", market: "moneyline", outcome: "home", label: "Lakers (vainqueur)", odds: 1.65 },
    ],
    stake: 120,
    totalOdds: 1.65,
    potentialPayout: 198,
    status: "pending",
    placedAt: "2026-07-10T20:00:00Z",
  },
  {
    id: "b4",
    selections: [
      { id: "m2-moneyline-away", matchId: "m2", matchLabel: "Warriors vs Nets", market: "moneyline", outcome: "away", label: "Nets (vainqueur)", odds: 2.9 },
    ],
    stake: 55,
    totalOdds: 2.9,
    potentialPayout: 159,
    status: "pending",
    placedAt: "2026-07-10T22:30:00Z",
  },
];

// TEMPORAIRE : sera remplacé par les endpoints /api/bets (GET) et /api/bets (POST) du backend.
export async function fetchBets(): Promise<PlacedBet[]> {
  await new Promise((r) => setTimeout(r, 500));
  return bets;
}

export async function placeBet(bet: PlacedBet): Promise<PlacedBet> {
  await new Promise((r) => setTimeout(r, 500));
  bets = [bet, ...bets];
  return bet;
}