import { WalletData, WalletTransaction } from "@/lib/types";

const MOCK_BALANCE: WalletData = { balance: 1240 };

// Historique étendu (12 mouvements) pour alimenter le graphique d'évolution du solde du dashboard.
// Triés du plus récent au plus ancien, comme le reste des listes de l'app.
const MOCK_TRANSACTIONS: WalletTransaction[] = [
  { id: "12", type: "bet_win", amount: 209, description: "Celtics vs Warriors — Vainqueur", date: "2026-07-12T21:00:00Z" },
  { id: "11", type: "bet_placed", amount: -55, description: "Warriors vs Nets — Moneyline", date: "2026-07-10T20:00:00Z" },
  { id: "10", type: "bet_win", amount: 120, description: "Nuggets vs Suns — Total de points", date: "2026-07-08T21:00:00Z" },
  { id: "9", type: "bet_placed", amount: -95, description: "Heat vs Lakers — Vainqueur", date: "2026-07-07T15:00:00Z" },
  { id: "8", type: "bet_win", amount: 65, description: "Warriors vs Nets — Handicap", date: "2026-07-06T22:00:00Z" },
  { id: "7", type: "bet_placed", amount: -40, description: "Nuggets vs Suns — Total de points", date: "2026-07-06T17:00:00Z" },
  { id: "6", type: "bet_win", amount: 150, description: "Lakers vs Celtics — Vainqueur", date: "2026-07-05T20:00:00Z" },
  { id: "5", type: "bet_loss", amount: -100, description: "Warriors vs Nets — Total de points", date: "2026-07-04T19:30:00Z" },
  { id: "4", type: "bet_placed", amount: -50, description: "Bucks vs Heat — Handicap", date: "2026-07-03T18:00:00Z" },
  { id: "3", type: "bet_win", amount: 96, description: "Bucks vs Heat — Handicap", date: "2026-07-02T21:30:00Z" },
  { id: "2", type: "bet_placed", amount: -60, description: "Lakers vs Celtics — Vainqueur", date: "2026-07-02T14:00:00Z" },
  { id: "1", type: "bonus", amount: 1000, description: "Capital de départ", date: "2026-07-01T10:00:00Z" },
];

// TEMPORAIRE : sera remplacé par fetch("/api/wallet") vers le backend NestJS.
export async function fetchWallet(): Promise<WalletData> {
  await new Promise((r) => setTimeout(r, 600));
  return MOCK_BALANCE;
}

export async function fetchWalletTransactions(): Promise<WalletTransaction[]> {
  await new Promise((r) => setTimeout(r, 800));
  return MOCK_TRANSACTIONS;
}