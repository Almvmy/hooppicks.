"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, Wallet } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { buttonVariants } from "@/components/ui/button";
import { AreaChart } from "@/components/ui/area-chart";
import { fetchProfile } from "@/lib/api/auth";
// TEMPORAIRE : le solde consomme encore le module mock, en attendant l'étape
// suivante (branchement de "@/lib/api/wallet").
import { fetchWallet, fetchWalletTransactions } from "@/lib/mock/wallet";
import { computeBalanceSeries, computeSeriesDelta } from "@/lib/dashboard";
import { cn } from "@/lib/utils";

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 5) return "Bonne nuit";
  if (hour < 12) return "Bonjour";
  if (hour < 18) return "Bon après-midi";
  return "Bonsoir";
}

export function DashboardHero() {
  const profileQuery = useQuery({ queryKey: ["profile"], queryFn: fetchProfile });
  const walletQuery = useQuery({ queryKey: ["wallet"], queryFn: fetchWallet });
  const txQuery = useQuery({
    queryKey: ["wallet-transactions-dashboard"],
    queryFn: fetchWalletTransactions,
  });

  const isLoading = profileQuery.isLoading || walletQuery.isLoading || txQuery.isLoading;
  const isError = profileQuery.isError || walletQuery.isError || txQuery.isError;

  const series =
    walletQuery.data && txQuery.data
      ? computeBalanceSeries(txQuery.data, walletQuery.data.balance)
      : [];
  const { diff, percent } = computeSeriesDelta(series);
  const isUp = diff >= 0;

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-card">
      <div
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl"
        aria-hidden
      />
      <div className="pointer-events-none absolute -bottom-32 left-1/3 h-64 w-64 rounded-full bg-primary/10 blur-3xl" aria-hidden />

      <div className="relative flex flex-col gap-6 p-6 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-4">
          <div>
            {isLoading ? (
              <Skeleton className="h-4 w-40" />
            ) : (
              <p className="text-sm text-muted-foreground">
                {getGreeting()}
                {!isError && profileQuery.data ? `, ${profileQuery.data.username}` : ""} 👋
              </p>
            )}
            <h1 className="mt-1 font-heading text-2xl font-bold sm:text-3xl">
              Bienvenue sur ton tableau de bord
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Wallet className="h-4.5 w-4.5" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Solde actuel</p>
              {isLoading ? (
                <Skeleton className="mt-1 h-9 w-32" />
              ) : isError || !walletQuery.data ? (
                <p className="font-heading text-3xl font-bold text-destructive">—</p>
              ) : (
                <div className="flex items-center gap-2">
                  <p className="font-heading text-3xl font-bold tabular-nums">
                    {walletQuery.data.balance.toLocaleString("fr-FR")}
                    <span className="ml-1 text-base font-medium text-muted-foreground">pts</span>
                  </p>
                  {series.length > 1 && (
                    <span
                      className={cn(
                        "flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-xs font-medium",
                        isUp ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                      )}
                    >
                      <ArrowUpRight className={cn("h-3 w-3", !isUp && "rotate-90")} />
                      {isUp ? "+" : ""}
                      {percent.toFixed(0)}%
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex w-full flex-col gap-3 sm:w-64">
          {isLoading ? (
            <Skeleton className="h-20 w-full" />
          ) : series.length > 1 ? (
            <div className="text-primary">
              <AreaChart
                values={series.map((p) => p.balance)}
                height={72}
                gradientFromClassName="text-primary"
                strokeClassName="stroke-primary"
              />
              <p className="mt-1 text-right text-xs text-muted-foreground">
                Évolution sur les 12 derniers mouvements
              </p>
            </div>
          ) : null}

          <div className="flex flex-wrap gap-2">
            <Link href="/matches" className={cn(buttonVariants({ variant: "default", size: "sm" }), "flex-1")}>
              Voir les matchs
            </Link>
            <Link href="/leaderboard" className={cn(buttonVariants({ variant: "outline", size: "sm" }), "flex-1")}>
              Classement
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
