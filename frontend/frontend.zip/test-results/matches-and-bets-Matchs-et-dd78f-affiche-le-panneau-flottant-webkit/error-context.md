# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: matches-and-bets.spec.ts >> Matchs et paris >> ajoute une sélection au ticket et affiche le panneau flottant
- Location: tests\matches-and-bets.spec.ts:21:7

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/dashboard/
Error: RangeError: Out of memory

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    2 × unexpected value "http://localhost:3000/login"

```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | 
  3  | test.describe("Matchs et paris", () => {
  4  |   test.beforeEach(async ({ page, context }) => {
  5  |     await context.clearCookies();
  6  |     await page.goto("/login");
  7  |     await page.getByLabel("Adresse e-mail").fill("test@exemple.com");
  8  |     await page.getByLabel("Mot de passe").fill("motdepasse");
  9  |     await page.getByRole("button", { name: "Se connecter" }).click();
> 10 |     await expect(page).toHaveURL(/\/dashboard/);
     |                        ^ Error: expect(page).toHaveURL(expected) failed
  11 |   });
  12 | 
  13 |   test("affiche la liste des matchs et permet de filtrer par conférence", async ({ page }) => {
  14 |     await page.goto("/matches");
  15 |     await expect(page.getByText("Lakers").first()).toBeVisible();
  16 | 
  17 |     await page.getByText("Est", { exact: true }).click();
  18 |     await expect(page.getByText("Ouest", { exact: true })).toBeVisible();
  19 |   });
  20 | 
  21 |   test("ajoute une sélection au ticket et affiche le panneau flottant", async ({ page }) => {
  22 |     await page.goto("/matches");
  23 | 
  24 |     const oddsButtons = page.locator("button", { hasText: /\d\.\d{2}/ });
  25 |     await oddsButtons.first().click();
  26 | 
  27 |     await expect(page.getByText(/Ticket \(1\)/)).toBeVisible();
  28 |   });
  29 | 
  30 |   test("bloque la validation si la mise dépasse le solde", async ({ page }) => {
  31 |     await page.goto("/matches");
  32 | 
  33 |     const oddsButtons = page.locator("button", { hasText: /\d\.\d{2}/ });
  34 |     await oddsButtons.first().click();
  35 | 
  36 |     await page.getByPlaceholder("Mise en points").fill("999999");
  37 |     await expect(page.getByText(/Solde insuffisant/)).toBeVisible();
  38 |     await expect(page.getByRole("button", { name: "Valider le ticket" })).toBeDisabled();
  39 |   });
  40 | });
```