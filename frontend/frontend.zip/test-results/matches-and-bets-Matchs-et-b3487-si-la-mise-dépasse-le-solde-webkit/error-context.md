# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: matches-and-bets.spec.ts >> Matchs et paris >> bloque la validation si la mise dépasse le solde
- Location: tests\matches-and-bets.spec.ts:30:7

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
Error: browserContext.newPage: Test timeout of 30000ms exceeded.
```